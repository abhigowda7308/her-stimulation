# HER Gazebo Simulation
## Virtual Robotic Laboratory for HER Electrocatalyst Testing
### Dissertation Project — ROS 2 Jazzy + Gazebo Harmonic

---

## What This Simulation Does

This package simulates a **virtual robotic laboratory** that automates the testing of
HER (Hydrogen Evolution Reaction) electrocatalyst candidates predicted by the ML models
in Notebooks 1 and 2.

A 2-joint robot arm performs the full 6-step HER test protocol:

| Step | Action   | Station              | Description                          |
|------|----------|----------------------|--------------------------------------|
| 1    | PICK     | S1 Sample Storage    | Gripper retrieves catalyst sample    |
| 2    | DISPENSE | S2 Electrolyte Prep  | Dispense electrolyte into cell       |
| 3    | IMMERSE  | S3 Electrochemical   | Lower electrode into cell            |
| 4    | MEASURE  | S4 Potentiostat      | Apply LSV voltage sweep              |
| 5    | ANALYSE  | S4 Potentiostat      | Compute Tafel slope                  |
| 6    | LOG      | S5 Data Logger       | Record results to database           |

---

## System Requirements

- Ubuntu 24.04 LTS
- ROS 2 Jazzy
- Gazebo Harmonic 8.x
- Python 3.12
- pandas, numpy, scipy, matplotlib

---

## Package Structure

```
her_robot_sim/
├── her_robot_sim/
│   ├── __init__.py
│   └── her_robot_controller.py   ← Main ROS2 Python controller node
├── worlds/
│   └── her_lab_world.sdf         ← 3D lab environment (Gazebo world)
├── urdf/
│   └── robot_arm.urdf            ← Robot arm model (2-DOF + gripper)
├── launch/
│   └── launch_her_simulation.py  ← One-click launch file
├── resource/
│   └── her_robot_sim
├── package.xml
├── setup.py
├── setup.cfg
└── README.md
```

---

## SETUP — Run These Commands Once

### Step 1: Create a ROS 2 workspace

```bash
mkdir -p ~/her_ws/src
cd ~/her_ws/src
```

### Step 2: Copy this package into the workspace

```bash
cp -r ~/her_gazebo_sim/her_robot_sim ~/her_ws/src/
```

### Step 3: Install dependencies

```bash
cd ~/her_ws
sudo apt update
sudo apt install -y \
    ros-jazzy-robot-state-publisher \
    ros-jazzy-joint-trajectory-controller \
    ros-jazzy-ros-gz \
    ros-jazzy-ros-gz-bridge \
    ros-jazzy-ros-gz-sim
```

### Step 4: Build the package

```bash
cd ~/her_ws
source /opt/ros/jazzy/setup.bash
colcon build --packages-select her_robot_sim
source install/setup.bash
```

---

## RUNNING THE SIMULATION

### Every time you open a new terminal, source ROS first:

```bash
source /opt/ros/jazzy/setup.bash
source ~/her_ws/install/setup.bash
```

### Launch the full simulation (one command):

```bash
ros2 launch her_robot_sim launch_her_simulation.py
```

This will:
1. Open Gazebo with the HER lab environment
2. Spawn the robot arm on the bench
3. Start the ROS-Gazebo bridge
4. Wait 5 seconds for everything to load
5. Start the controller — robot begins testing all 10 catalysts automatically

---

## MONITORING THE SIMULATION

Open a second terminal and run any of these:

```bash
# Watch live status updates
source /opt/ros/jazzy/setup.bash && source ~/her_ws/install/setup.bash
ros2 topic echo /her_robot/status

# Watch result as each catalyst finishes
ros2 topic echo /her_robot/results

# Watch joint positions in real time
ros2 topic echo /joint_states

# List all active topics
ros2 topic list
```

---

## RESULTS

Results are saved automatically to:

```
~/her_simulation_results/
├── her_gazebo_results_all.csv          ← All 10 catalysts
├── her_gazebo_results_alternative.csv  ← Non-Pt catalysts only
└── her_gazebo_results_compound.csv     ← Pt catalysts only
```

Each CSV contains:
- Catalyst ID, name, electrolyte
- ML predicted overpotential & Tafel slope
- Simulated overpotential & Tafel slope
- Current density at -300 mV
- Onset potential
- Performance score (0–100)
- Timestamp

---

## TROUBLESHOOTING

**Gazebo does not open:**
```bash
gz sim --version   # Should show 8.x
export GZ_VERSION=harmonic
```

**Robot not spawning:**
```bash
# Check robot_state_publisher is running
ros2 node list | grep robot_state
```

**Controller not connecting:**
```bash
# Re-source and rebuild
cd ~/her_ws && colcon build && source install/setup.bash
```

**Package not found after build:**
```bash
source ~/her_ws/install/setup.bash
ros2 pkg list | grep her_robot
```

---

## ROS 2 Topics Published

| Topic                                        | Type                     | Description              |
|----------------------------------------------|--------------------------|--------------------------|
| `/her_robot/status`                          | std_msgs/String          | Live step-by-step status |
| `/her_robot/results`                         | std_msgs/String (JSON)   | Result per catalyst      |
| `/her_robot/lsv_data`                        | std_msgs/Float64MultiArray | LSV curve data         |
| `/joint_trajectory_controller/joint_trajectory` | trajectory_msgs/JointTrajectory | Arm commands      |

---

*Dissertation Project — Electrocatalyst Development for HER via ML + Gazebo Simulation*
