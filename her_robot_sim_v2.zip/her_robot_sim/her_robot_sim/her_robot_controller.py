#!/usr/bin/env python3
"""
HER Robot Controller Node v2
Uses direct Gazebo joint position commands (no ros2_control needed).
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Float64, Float64MultiArray
import numpy as np
import pandas as pd
import json, time, os, math
from datetime import datetime

# ── Catalyst candidates from ML models ──
ALTERNATIVE_CATALYSTS = [
    {'id': 'ALT-01', 'name': 'IrCo@NC-500', 'electrolyte': '1 M KOH',     'label': 'Best',      'pred_ovp': 28.0, 'pred_tafel': 29.0},
    {'id': 'ALT-02', 'name': 'RuCo@NC',      'electrolyte': '0.5 M H2SO4', 'label': 'Best',      'pred_ovp': 33.0, 'pred_tafel': 32.0},
    {'id': 'ALT-03', 'name': 'FeP/C',         'electrolyte': '1 M KOH',     'label': 'Excellent', 'pred_ovp': 41.0, 'pred_tafel': 38.0},
    {'id': 'ALT-04', 'name': 'CoP/C',         'electrolyte': '1 M KOH',     'label': 'Excellent', 'pred_ovp': 47.0, 'pred_tafel': 44.0},
    {'id': 'ALT-05', 'name': 'NiRu@N-C',      'electrolyte': '1 M PBS',     'label': 'Excellent', 'pred_ovp': 52.0, 'pred_tafel': 46.0},
]
COMPOUND_CATALYSTS = [
    {'id': 'CPT-01', 'name': 'Pt/N-C',            'electrolyte': '0.1 M HClO4', 'label': 'Best',      'pred_ovp': 18.0, 'pred_tafel': 22.0},
    {'id': 'CPT-02', 'name': 'PtNi NW',            'electrolyte': '0.5 M H2SO4', 'label': 'Best',      'pred_ovp': 22.0, 'pred_tafel': 26.0},
    {'id': 'CPT-03', 'name': 'Pt/A-CN',            'electrolyte': '1 M KOH',     'label': 'Excellent', 'pred_ovp': 31.0, 'pred_tafel': 30.0},
    {'id': 'CPT-04', 'name': 'Pt nanocluster/S-C', 'electrolyte': '0.5 M H2SO4', 'label': 'Excellent', 'pred_ovp': 35.0, 'pred_tafel': 34.0},
    {'id': 'CPT-05', 'name': '20pct Pt/C',         'electrolyte': '1 M KOH',     'label': 'Excellent', 'pred_ovp': 38.0, 'pred_tafel': 37.0},
]

# ── 6-step HER test protocol ──
HER_PROTOCOL = [
    {'step': 1, 'name': 'Sample Loading',          'station': 'S1', 'shoulder': math.radians(130), 'elbow': math.radians(-65), 'action': 'PICK',     'duration': 3.0},
    {'step': 2, 'name': 'Electrolyte Preparation', 'station': 'S2', 'shoulder': math.radians(100), 'elbow': math.radians(-55), 'action': 'DISPENSE', 'duration': 3.5},
    {'step': 3, 'name': 'Electrode Immersion',     'station': 'S3', 'shoulder': math.radians(60),  'elbow': math.radians(-40), 'action': 'IMMERSE',  'duration': 2.5},
    {'step': 4, 'name': 'LSV Voltage Sweep',       'station': 'S4', 'shoulder': math.radians(25),  'elbow': math.radians(-25), 'action': 'MEASURE',  'duration': 5.0},
    {'step': 5, 'name': 'Tafel Analysis',          'station': 'S4', 'shoulder': math.radians(25),  'elbow': math.radians(-25), 'action': 'ANALYSE',  'duration': 2.5},
    {'step': 6, 'name': 'Data Logging',            'station': 'S5', 'shoulder': math.radians(5),   'elbow': math.radians(-15), 'action': 'LOG',      'duration': 2.0},
]
HOME = {'shoulder': math.radians(90), 'elbow': math.radians(-45)}


def simulate_lsv(ovp_mV, tafel_mV, j0=1e-3, noise=0.02):
    eta_onset = ovp_mV / 1000.0
    b = tafel_mV / 1000.0
    potential = np.linspace(0, -0.6, 300)
    current = np.zeros(300)
    for i, eta in enumerate(potential):
        eta_abs = abs(eta)
        if eta_abs >= eta_onset:
            j = j0 * (10 ** ((eta_abs - eta_onset) / b)) * 1000
            current[i] = -min(j, 200)
        else:
            current[i] = -j0 * 10 * 1000
    current += np.random.normal(0, noise * np.abs(current), size=len(current))
    return potential, current


def perf_score(ovp, tafel):
    return float(np.clip(100 - (ovp * 0.5 + tafel * 0.5) / 10, 0, 100))


class HERRobotController(Node):

    def __init__(self):
        super().__init__('her_robot_controller')

        # Publishers for direct Gazebo joint commands
        self.shoulder_pub = self.create_publisher(
            Float64,
            '/model/her_robot_arm/joint/shoulder_joint/cmd_pos', 10)
        self.elbow_pub = self.create_publisher(
            Float64,
            '/model/her_robot_arm/joint/elbow_joint/cmd_pos', 10)

        # Status and results topics
        self.status_pub = self.create_publisher(String, '/her_robot/status', 10)
        self.result_pub = self.create_publisher(String, '/her_robot/results', 10)
        self.lsv_pub    = self.create_publisher(Float64MultiArray, '/her_robot/lsv_data', 10)

        self.results = []
        self.all_catalysts = ALTERNATIVE_CATALYSTS + COMPOUND_CATALYSTS

        self.get_logger().info('=' * 55)
        self.get_logger().info('  HER ROBOT CONTROLLER — Ready')
        self.get_logger().info(f'  Catalysts to test: {len(self.all_catalysts)}')
        self.get_logger().info('=' * 55)

        # Start simulation after 2s delay
        self.timer = self.create_timer(2.0, self.start_simulation)

    def move_joints(self, shoulder_rad, elbow_rad):
        """Send direct joint position commands to Gazebo."""
        s_msg = Float64()
        s_msg.data = shoulder_rad
        e_msg = Float64()
        e_msg.data = elbow_rad
        self.shoulder_pub.publish(s_msg)
        self.elbow_pub.publish(e_msg)

    def publish_status(self, msg_str):
        msg = String()
        msg.data = msg_str
        self.status_pub.publish(msg)
        self.get_logger().info(f'  STATUS: {msg_str}')

    def start_simulation(self):
        self.timer.cancel()
        self.get_logger().info('')
        self.get_logger().info('  Starting HER automated testing...')
        self.move_joints(HOME['shoulder'], HOME['elbow'])
        time.sleep(2.5)

        for cat in self.all_catalysts:
            self.test_catalyst(cat)

        self.save_results()
        self.print_summary()

    def test_catalyst(self, cat):
        self.get_logger().info('-' * 55)
        self.get_logger().info(f"  Testing: {cat['name']}  [{cat['id']}]  Label: {cat['label']}")
        self.get_logger().info(f"  Predicted η={cat['pred_ovp']} mV  Tafel={cat['pred_tafel']} mV/dec")

        step_data = {}

        for p in HER_PROTOCOL:
            self.publish_status(f"[{cat['id']}] Step {p['step']}: {p['name']}")
            self.move_joints(p['shoulder'], p['elbow'])
            time.sleep(p['duration'])

            if p['action'] == 'MEASURE':
                var = np.random.uniform(-0.025, 0.025)
                sim_ovp   = cat['pred_ovp']   * (1 + var)
                sim_tafel = cat['pred_tafel'] * (1 + var)
                pot, cur  = simulate_lsv(sim_ovp, sim_tafel)

                idx_300 = np.argmin(np.abs(pot + 0.3))
                step_data = {
                    'sim_ovp':   round(sim_ovp, 2),
                    'sim_tafel': round(sim_tafel, 2),
                    'j_300mV':   round(abs(cur[idx_300]), 3),
                }
                lsv_msg = Float64MultiArray()
                lsv_msg.data = list(pot) + list(cur)
                self.lsv_pub.publish(lsv_msg)

                self.get_logger().info(
                    f"  [{p['action']:8s}] {p['name']:25s} ✓"
                    f"  η={sim_ovp:.1f} mV  b={sim_tafel:.1f} mV/dec")
            else:
                self.get_logger().info(f"  [{p['action']:8s}] {p['name']:25s} ✓")

        # Return home
        self.move_joints(HOME['shoulder'], HOME['elbow'])
        time.sleep(2.0)

        score = perf_score(
            step_data.get('sim_ovp', cat['pred_ovp']),
            step_data.get('sim_tafel', cat['pred_tafel'])
        )

        result = {
            'Catalyst_ID':         cat['id'],
            'Electrocatalyst':     cat['name'],
            'Electrolyte':         cat['electrolyte'],
            'ML_Label':            cat['label'],
            'Predicted_Ovp_mV':   cat['pred_ovp'],
            'Simulated_Ovp_mV':   step_data.get('sim_ovp', cat['pred_ovp']),
            'Predicted_Tafel_mV': cat['pred_tafel'],
            'Simulated_Tafel_mV': step_data.get('sim_tafel', cat['pred_tafel']),
            'Current_at_300mV':   step_data.get('j_300mV', 0.0),
            'Performance_Score':  score,
            'Timestamp':          datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        }
        self.results.append(result)

        r_msg = String()
        r_msg.data = json.dumps({'id': result['Catalyst_ID'], 'name': result['Electrocatalyst'],
                                  'score': score, 'sim_ovp': result['Simulated_Ovp_mV']})
        self.result_pub.publish(r_msg)
        self.get_logger().info(f'  Score: {score:.1f}/100')

    def save_results(self):
        df  = pd.DataFrame(self.results)
        out = os.path.expanduser('~/her_simulation_results')
        os.makedirs(out, exist_ok=True)
        df.to_csv(f'{out}/her_gazebo_results_all.csv', index=False)
        df[df['Catalyst_ID'].str.startswith('ALT')].to_csv(f'{out}/her_gazebo_results_alternative.csv', index=False)
        df[df['Catalyst_ID'].str.startswith('CPT')].to_csv(f'{out}/her_gazebo_results_compound.csv', index=False)
        self.get_logger().info(f'  Results saved to {out}/')

    def print_summary(self):
        df = pd.DataFrame(self.results).sort_values('Performance_Score', ascending=False)
        self.get_logger().info('')
        self.get_logger().info('=' * 55)
        self.get_logger().info('  FINAL RESULTS — RANKED')
        self.get_logger().info('=' * 55)
        for i, (_, r) in enumerate(df.iterrows(), 1):
            self.get_logger().info(
                f"  #{i:2d}  {r['Electrocatalyst']:22s}  "
                f"Score={r['Performance_Score']:5.1f}  "
                f"eta={r['Simulated_Ovp_mV']:5.1f} mV")
        best = df.iloc[0]
        self.get_logger().info(f"\n  Best: {best['Electrocatalyst']} ({best['Performance_Score']:.1f}/100)")
        self.publish_status('Simulation complete')


def main(args=None):
    rclpy.init(args=args)
    node = HERRobotController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Stopped.')
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
