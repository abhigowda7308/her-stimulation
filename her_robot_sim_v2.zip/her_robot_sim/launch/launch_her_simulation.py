"""
HER Gazebo Simulation - Launch File v2
No joint_trajectory_controller needed.
"""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction
from launch_ros.actions import Node


def generate_launch_description():

    pkg_dir    = get_package_share_directory('her_robot_sim')
    world_file = os.path.join(pkg_dir, 'worlds', 'her_lab_world.sdf')
    urdf_file  = os.path.join(pkg_dir, 'urdf',   'robot_arm.urdf')

    with open(urdf_file, 'r') as f:
        robot_description = f.read()

    # 1. Gazebo
    gazebo = ExecuteProcess(
        cmd=['gz', 'sim', '-r', world_file],
        output='screen'
    )

    # 2. Robot State Publisher
    rsp = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_description, 'use_sim_time': True}]
    )

    # 3. Spawn robot
    spawn = TimerAction(period=2.0, actions=[
        Node(
            package='ros_gz_sim',
            executable='create',
            arguments=['-name', 'her_robot_arm', '-topic', 'robot_description',
                       '-x', '-0.7', '-y', '0.0', '-z', '0.44'],
            output='screen'
        )
    ])

    # 4. ROS-Gazebo bridge
    bridge = TimerAction(period=3.0, actions=[
        Node(
            package='ros_gz_bridge',
            executable='parameter_bridge',
            name='ros_gz_bridge',
            arguments=[
                '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock',
                '/joint_states@sensor_msgs/msg/JointState[gz.msgs.Model',
                '/model/her_robot_arm/joint/shoulder_joint/cmd_pos@std_msgs/msg/Float64]gz.msgs.Double',
                '/model/her_robot_arm/joint/elbow_joint/cmd_pos@std_msgs/msg/Float64]gz.msgs.Double',
            ],
            output='screen'
        )
    ])

    # 5. HER Controller (delayed 6s for Gazebo to fully load)
    controller = TimerAction(period=6.0, actions=[
        Node(
            package='her_robot_sim',
            executable='her_robot_controller',
            name='her_robot_controller',
            output='screen',
            parameters=[{'use_sim_time': True}]
        )
    ])

    return LaunchDescription([gazebo, rsp, spawn, bridge, controller])
